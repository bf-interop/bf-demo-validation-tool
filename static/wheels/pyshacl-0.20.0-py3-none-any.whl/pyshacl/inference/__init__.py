# -*- coding: utf-8 -*-
from .custom_rdfs_closure import CustomRDFSOWLRLSemantics, CustomRDFSSemantics


__all__ = ['CustomRDFSSemantics', 'CustomRDFSOWLRLSemantics']
